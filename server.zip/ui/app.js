window.addEventListener('message', (event) => {
    let data = event.data
  
    if (data.type === 'open') {

    } else if (data.type === 'close') {
        
    }
});